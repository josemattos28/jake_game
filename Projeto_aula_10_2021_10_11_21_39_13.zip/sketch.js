
function preload(){
  //imagens pré-carregadas
}

function setup(){
  createCanvas(400,400);
  //crie os sprites aqui
}

function draw() {
  background(0);

}
